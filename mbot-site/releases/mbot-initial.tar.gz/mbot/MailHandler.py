#!/usr/bin/env python

# mbot - a mail handling robot
#
# Author:  Dimitri Fontaine <dim@tapoueh.org>
# Author:  Christophe Truffier <toffe@nah-ko..org>
#
# This code is licensed under the GPL.
# Get yourself a version here : http://www.gnu.org/copyleft/gpl.html

# $Id: MailHandler.py,v 1.7 2003/06/02 16:04:52 nah-ko Exp $

SECTION = ""

class MailHandler:
    " To handle a mail, you'll have to inheritate from this class "
    def __init__(self, params, dest="sended for", sender="sended by", date="sended the"):
        self.params = params
	self.date   = date
	self.sender = sender
	self.dest   = dest

    def read_conf(self, config):
	''' Config parser '''
    	pass
    
    def handle(self, body):
        return [('text/plain', body)]

